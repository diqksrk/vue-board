<template>
  <div id="app">
    <TopMenu></TopMenu>
    <router-view></router-view>
    <bottom-info></bottom-info>
  </div>
</template>

<script>

import VueRouter from 'vue-router'
import Main from './components/main/Main.vue'
import BoardMain from './components/board/BoardMain.vue'
import TopMenu from './components/common/TopMenu.vue'
import BottomInfo from './components/common/BottomInfo.vue'

const router = new VueRouter({
    routes : [
        {
            path : '/',
            component : Main
        },
        {
            path : '/board_main',
            component : BoardMain
        }
    ]
})

export default {
  name: 'app',
  components: {
    TopMenu,
    BottomInfo
  },
  router
}

</script>
